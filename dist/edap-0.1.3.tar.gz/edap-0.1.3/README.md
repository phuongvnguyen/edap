# edap 0.0.1

### What is edap?
**edap** stands for **E**xploratory **d**ata **a**nalysis  **p**huong, which has beeen developed and maintained by Phuong V. Nguyen. It is an open-source, low-code library in Python.

One can use **edap** locally by using one of two ways as follows.

```
pip install -i https://test.pypi.org/simple/ edap==0.1.3
```

```
https://github.com/phuongvnguyen/edap.git
```
